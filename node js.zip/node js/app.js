var fs = require('fs');

//Sync version of reading and writing to a file
//reading file in node js

var readMe = fs.readFileSync('readme.txt', 'utf8');

//write a file

fs.writeFileSync('writeMe.txt', readMe);



//ASync version of reading and writing to a file
//reading file in node js

fs.readFile('readme.txt', 'utf8', function(err, data){
    //write a file
    fs.writeFile('writeMee.txt', data);
});
